#!/usr/bin/env bash
set -euo pipefail

# Apply the bounded Library of Alexandria vertical slice to an R3 dev release.
# Run from the R3 release directory, e.g.:
#   cd /home/hstone/Documents/games/rollamacoaster-tycoon/r3/R3.0-dev.24
#   bash /path/to/APPLY_R3_LOA_DEV25.sh

ROOT="${1:-$PWD}"
ROOT="$(cd "$ROOT" && pwd)"
TOOLS="$ROOT/tools/r3_loa_dev25"
SERVER="$ROOT/rct_r3_dev_server.py"
LAUNCHER="$ROOT/run_rct_r3_dev.sh"
HTML="$ROOT/rollamacoasterTycoon_R3_rebuilt.html"

say(){ printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }
die(){ printf '\033[1;31mERROR:\033[0m %s\n' "$*" >&2; exit 1; }

[[ -f "$SERVER" ]] || die "Missing $SERVER"
[[ -f "$LAUNCHER" ]] || die "Missing $LAUNCHER"
[[ -f "$HTML" ]] || die "Missing $HTML"

mkdir -p "$TOOLS"

# Resolve the directory this bundle was launched from so helper files can be copied.
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for f in r3_loa_patch_server.py r3_loa_inject_html.py r3_guestprofile_const_scan.py R3_LOA_DEV25_GATE.sh; do
  [[ -f "$SELF_DIR/$f" ]] || die "Bundle helper missing: $SELF_DIR/$f"
  cp "$SELF_DIR/$f" "$TOOLS/$f"
done
chmod +x "$TOOLS"/*.py "$TOOLS"/*.sh

say "Backing up R3 dev server and launcher"
[[ -f "$SERVER.pre-loa-dev25" ]] || cp "$SERVER" "$SERVER.pre-loa-dev25"
[[ -f "$LAUNCHER.pre-loa-dev25" ]] || cp "$LAUNCHER" "$LAUNCHER.pre-loa-dev25"
[[ -f "$HTML.pre-loa-dev25" ]] || cp "$HTML" "$HTML.pre-loa-dev25"

say "Patching same-origin Alexandria routes into the R3 dev server"
python3 "$TOOLS/r3_loa_patch_server.py" "$SERVER"

say "Injecting the non-blocking browser Alexandria adapter"
python3 "$TOOLS/r3_loa_inject_html.py" "$HTML"

say "Making the HTML adapter re-apply after every R3 release step"
python3 - "$LAUNCHER" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1])
s = p.read_text()
marker = '# R3_LOA_DEV25_LAUNCH_HOOK'
if marker in s:
    print('Launcher hook already present.')
    raise SystemExit(0)
needle = 'python3 rct_r3_release.py --codex "$CODEX"\n'
if needle not in s:
    raise SystemExit('Could not locate rct_r3_release.py invocation in launcher; refusing unsafe patch.')
insert = needle + '''\n# R3_LOA_DEV25_LAUNCH_HOOK\n# Re-apply the bounded browser adapter after release generation/staging.\npython3 tools/r3_loa_dev25/r3_loa_inject_html.py rollamacoasterTycoon_R3_rebuilt.html\n'''
p.write_text(s.replace(needle, insert, 1))
print('Launcher hook installed.')
PY

say "Static validation"
python3 -m py_compile "$SERVER" "$TOOLS/r3_loa_patch_server.py" "$TOOLS/r3_loa_inject_html.py" "$TOOLS/r3_guestprofile_const_scan.py"
bash -n "$LAUNCHER"
grep -q 'R3_LOA_DEV25_SERVER_BEGIN' "$SERVER"
grep -q 'R3_LOA_DEV25_BROWSER_BEGIN' "$HTML"
grep -q 'R3_LOA_DEV25_LAUNCH_HOOK' "$LAUNCHER"

say "Main-goal guard: scan guestProfile for likely const reassignments"
python3 "$TOOLS/r3_guestprofile_const_scan.py" "$HTML" || true

cat <<'TXT'

APPLIED.

Next:
  1. Keep Alexandria running with your existing loa-runtime/ALEXANDRIA tooling.
  2. Start R3 normally, preferably on 8766:
       bash run_rct_r3_dev.sh 8766
  3. In another terminal run:
       bash tools/r3_loa_dev25/R3_LOA_DEV25_GATE.sh http://127.0.0.1:8766

Main-goal boundary:
  - P0 remains the guestProfile/runtime operations fault.
  - LoA is a bounded P1 vertical slice, not a replacement for R3 simulation work.
  - Entertainer-hiring crash stays documented/deferred for this cycle.
TXT
