#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-$PWD}"
ROOT="$(cd "$ROOT" && pwd)"
for name in rct_r3_dev_server.py run_rct_r3_dev.sh rollamacoasterTycoon_R3_rebuilt.html; do
  bak="$ROOT/$name.pre-loa-dev25"
  if [[ -f "$bak" ]]; then
    cp "$bak" "$ROOT/$name"
    echo "restored $name"
  else
    echo "no backup for $name" >&2
  fi
done
rm -rf "$ROOT/tools/r3_loa_dev25"
echo "R3 LoA dev.25 integration reverted from backups."
