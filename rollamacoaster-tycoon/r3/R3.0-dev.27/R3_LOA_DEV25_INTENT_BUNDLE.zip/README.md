# R3 dev.25 + Library of Alexandria bounded integration bundle

This bundle is designed to keep **rollamacoasterTycoon R3** as the main project while adding the working Library of Alexandria runtime as one small, testable knowledge vertical slice.

## Main-goal order

1. **P0: fix the dev.24 `guestProfile` runtime operations crash.**
2. **P1: LoA same-origin bridge + non-blocking browser adapter + cache.**
3. Continue the dev.24 review queue.
4. Keep the recorded entertainer-hiring crash deferred for the next cycle.

The LoA work is deliberately additive. It does not replace R3's native IndexedDB Alexandria/Codex/entity-brain systems.

## Files

- `APPLY_R3_LOA_DEV25.sh` - install/patch the bounded integration.
- `r3_loa_patch_server.py` - adds R3 same-origin LoA status/search/document routes.
- `r3_loa_inject_html.py` - adds `window.R3Alexandria` to the game artifact without blocking boot.
- `R3_LOA_DEV25_GATE.sh` - repeatable CLI gate against a running R3 dev server.
- `r3_guestprofile_const_scan.py` - static guard/report for the dev.24 `Assignment to constant variable` fault. It intentionally does not blind-edit gameplay logic.
- `REVERT_R3_LOA_DEV25.sh` - restore backups made by the apply script.

## Apply

```bash
cd /home/hstone/Documents/games/rollamacoaster-tycoon/r3/R3.0-dev.24
unzip /path/to/R3_LOA_DEV25_INTENT_BUNDLE.zip -d /tmp/r3-loa-dev25
bash /tmp/r3-loa-dev25/APPLY_R3_LOA_DEV25.sh "$PWD"
```

The apply step installs its persistent helpers under:

```text
tools/r3_loa_dev25/
```

It also hooks the normal R3 launcher so the HTML adapter is re-injected after the release step.

## Run

Keep the LoA runtime managed separately with the operator tooling already created.

Then start R3:

```bash
bash run_rct_r3_dev.sh 8766
```

Optionally override the LoA web endpoint when launching R3:

```bash
RCT_LOA_BASE=http://127.0.0.1:8090 bash run_rct_r3_dev.sh 8766
```

## CLI test gate

In another terminal:

```bash
bash tools/r3_loa_dev25/R3_LOA_DEV25_GATE.sh http://127.0.0.1:8766
```

If your known indexed probe uses another keyword:

```bash
R3_LOA_TEST_QUERY='GREEN' bash tools/r3_loa_dev25/R3_LOA_DEV25_GATE.sh http://127.0.0.1:8766
```

## Browser test

Open DevTools in R3 and run:

```js
await R3Alexandria.status()
```

```js
await R3Alexandria.search('GREEN', {limit: 5})
```

```js
await R3Alexandria.queryForEntity('guest-test', 'GREEN', {force: true, limit: 5})
```

Results are cached non-invasively in:

```text
IndexedDB
  RCT_R3_AlexandriaLive
    results
```

The adapter also emits:

```text
r3:alexandria:online
r3:alexandria:offline
r3:alexandria:query
r3:alexandria:results
r3:alexandria:error
r3:alexandria:cache-error
```

That gives the native R3 brain/knowledge code an integration seam without guessing or mutating unknown internal structures.

## Recommended next native hook

Once the bridge is green, add exactly one native listener inside the R3 source/generator that consumes `r3:alexandria:results` and writes selected results into the existing Alexandria store + entity brain records. Do that in source, not as another artifact monkeypatch.

Conceptually:

```js
window.addEventListener('r3:alexandria:results', async (event) => {
  const { entityId, query, data } = event.detail;
  // normalize -> existing Alexandria IndexedDB store
  // associate discovered source IDs with entity brain
  // increment knowledgeLearned only after persistence succeeds
});
```

## Offline resilience acceptance

With R3 already open:

1. stop LoA;
2. continue moving camera, building, simulating guests;
3. `await R3Alexandria.status()` should fail quickly;
4. R3 must not freeze, block boot, or stop frame updates;
5. restart LoA;
6. `status()` and `search()` should recover without reloading the game.

## Revert

```bash
bash /tmp/r3-loa-dev25/REVERT_R3_LOA_DEV25.sh \
  /home/hstone/Documents/games/rollamacoaster-tycoon/r3/R3.0-dev.24
```

## Why this bundle does not auto-fix `guestProfile`

The review packet recorded a repeated runtime `Assignment to constant variable` fault inside `guestProfile -> newGuest -> spawnTick -> operationsTick`. Blindly converting `const` to `let` could hide the symptom while corrupting guest invariants. The included scanner reports likely reassignments and keeps that fix as an explicit P0 source-level repair.
