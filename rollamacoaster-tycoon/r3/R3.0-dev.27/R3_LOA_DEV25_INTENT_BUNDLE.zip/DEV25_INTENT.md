# dev.25 intent lock

**Main goal:** continue rebuilding R3 faithfully from the dev.24 review packet.

**P0 stability:** repair the recurring `guestProfile` / operations-frame constant-assignment fault first.

**P1 LoA vertical slice:** use the now-working external Library of Alexandria as a same-origin, cache-first, non-blocking knowledge source for R3. Do not expose Elasticsearch or LoA internals to guest logic. Do not make every roaming guest generate live searches.

**Entity query triggers:** Browse, Research, park computer, player lookup, explicit AI/knowledge action, selected social-curiosity events.

**Guards:** global LoA concurrency 3, per-entity cooldown 30s, local cache, identical in-flight query dedupe, gameplay survives LoA outage.

**Persistence progression:** first prove bridge/cache. Next source-level pass connects the `r3:alexandria:results` event to R3's native Alexandria IndexedDB records and entity brain `knowledgeLearned` bookkeeping.

**Deferred:** entertainer-hiring crash remains recorded but not fixed in this cycle, per review instruction.
