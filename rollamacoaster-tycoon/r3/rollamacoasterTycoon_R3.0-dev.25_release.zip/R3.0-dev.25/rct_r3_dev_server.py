#!/usr/bin/env python3
"""RollamacoasterTycoon R3 playtest launcher + diagnostics collector.

Serves the exact standalone HTML artifact and captures the in-game development
Test Bench POSTs into timestamped session folders. Standard-library only.
"""
from __future__ import annotations

import argparse
import base64
import json
import os
import re
import threading
import webbrowser
import urllib.error
import urllib.request
import urllib.parse
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent
ARTIFACT = "rollamacoasterTycoon_R3_rebuilt.html"
SESSIONS = ROOT / "rct_r3_dev_sessions"
MAX_BODY = 80 * 1024 * 1024
DEFAULT_LOA_TIMEOUT = float(os.getenv("RCT_LOA_TIMEOUT", "6"))
DEFAULT_LOA_ARCHIVE_MAX = int(os.getenv("RCT_LOA_ARCHIVE_MAX_BYTES", str(16 * 1024 * 1024)))


def utcstamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def safe_name(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", value or "unknown")
    return value[:160] or "unknown"


def atomic_json(path: Path, payload) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


class Handler(SimpleHTTPRequestHandler):
    server_version = "RCT-R3-Dev/1.1"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def end_headers(self):
        self.send_header("Cache-Control", "no-store, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        super().end_headers()

    def log_message(self, fmt, *args):
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {self.address_string()} {fmt % args}")

    def _json(self, status: int, payload) -> None:
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _read_json(self):
        try:
            size = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            size = 0
        if size <= 0 or size > MAX_BODY:
            raise ValueError(f"invalid Content-Length {size}")
        raw = self.rfile.read(size)
        return json.loads(raw.decode("utf-8"))

    def _loa_base(self) -> str:
        return str(getattr(self.server, "loa_base", "") or "").rstrip("/")

    def _loa_url(self, path: str, query: dict | None = None) -> str:
        base = self._loa_base()
        if not base:
            raise RuntimeError("Library of Alexandria is not configured. Set RCT_LOA_BASE or pass --loa-base.")
        url = base + "/" + path.lstrip("/")
        if query:
            vals = {k: v for k, v in query.items() if v is not None and v != ""}
            url += "?" + urllib.parse.urlencode(vals, doseq=True)
        return url

    def _loa_request(self, path: str, query: dict | None = None, *, raw: bool = False, max_bytes: int | None = None):
        url = self._loa_url(path, query)
        req = urllib.request.Request(url, headers={"Accept": "*/*", "User-Agent": "RollamacoasterTycoon-R3-LoA-Bridge/1.0"})
        try:
            with urllib.request.urlopen(req, timeout=getattr(self.server, "loa_timeout", DEFAULT_LOA_TIMEOUT)) as resp:
                limit = max_bytes if max_bytes is not None else 8 * 1024 * 1024
                data = resp.read(limit + 1)
                if len(data) > limit:
                    raise ValueError(f"LoA response exceeds bridge limit of {limit} bytes")
                ctype = resp.headers.get("Content-Type", "application/octet-stream")
                if raw:
                    return data, ctype, resp.geturl()
                return json.loads(data.decode("utf-8")), ctype, resp.geturl()
        except urllib.error.HTTPError as exc:
            body = exc.read(4096).decode("utf-8", "replace")
            raise RuntimeError(f"LoA HTTP {exc.code}: {body[:500]}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"LoA unreachable: {exc.reason}") from exc

    def _loa_status(self, probe: bool = True):
        base = self._loa_base()
        out = {"ok": bool(base), "configured": bool(base), "reachable": False, "base": base or None,
               "searchEndpoint": "/document/find-by/keyword/{query}/", "documentEndpoint": "/document/{documentId}",
               "debugEndpoint": "/document/{documentId}/debug"}
        if not base or not probe:
            return out
        try:
            stats, _, _ = self._loa_request("statistics", max_bytes=2 * 1024 * 1024)
            out.update({"ok": True, "reachable": True, "statistics": stats})
        except Exception as exc:
            out.update({"ok": False, "reachable": False, "error": str(exc)})
        return out

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/":
            self.send_response(HTTPStatus.FOUND)
            self.send_header("Location", f"/{ARTIFACT}")
            self.end_headers()
            return
        if path == "/api/dev/status":
            self._json(200, {
                "ok": True,
                "collector": "rct_r3_dev_server.py",
                "root": str(ROOT),
                "artifact": ARTIFACT,
                "sessions": str(SESSIONS),
                "alexandria": self._loa_status(probe=False),
                "time": datetime.now(timezone.utc).isoformat(),
            })
            return
        if path == "/api/alexandria/status":
            info = self._loa_status(probe=True)
            self._json(200 if info.get("configured") else 200, info)
            return
        if path.startswith("/api/alexandria/document/"):
            try:
                tail = path[len("/api/alexandria/document/"):]
                debug = tail.endswith("/debug")
                doc_id = urllib.parse.unquote(tail[:-6] if debug else tail).strip("/")
                if not doc_id or len(doc_id) > 512:
                    raise ValueError("invalid Alexandria document id")
                if debug:
                    data, _, _ = self._loa_request(f"document/{urllib.parse.quote(doc_id, safe='')}/debug", max_bytes=4 * 1024 * 1024)
                    self._json(200, {"ok": True, "sourceId": doc_id, "debug": data})
                    return
                raw, ctype, upstream = self._loa_request(f"document/{urllib.parse.quote(doc_id, safe='')}", raw=True,
                                                          max_bytes=getattr(self.server, "loa_archive_max", DEFAULT_LOA_ARCHIVE_MAX))
                lower = ctype.lower()
                text = None
                if any(x in lower for x in ("text/", "json", "xml", "javascript", "csv", "html")):
                    text = raw.decode("utf-8", "replace")
                encoded = None if text is not None else base64.b64encode(raw).decode("ascii")
                self._json(200, {"ok": True, "sourceId": doc_id, "contentType": ctype, "bytes": len(raw),
                                 "text": text, "base64": encoded, "complete": True, "truncated": False,
                                 "upstream": upstream})
            except Exception as exc:
                self._json(502, {"ok": False, "error": str(exc)})
            return
        return super().do_GET()

    def do_POST(self):
        path = urlparse(self.path).path
        if path in {"/api/alexandria/search", "/api/alexandria/cache/prefetch"}:
            try:
                data = self._read_json()
                if path == "/api/alexandria/search":
                    query = str(data.get("query") or "").strip()
                    if len(query) < 3 or len(query) > 1000:
                        raise ValueError("Alexandria query must be between 3 and 1000 characters")
                    page = max(0, int(data.get("page") or 0))
                    result_size = min(50, max(1, int(data.get("resultSize") or 12)))
                    params = {"pageNumber": page * 10, "resultSize": result_size}
                    if data.get("exactMatch"):
                        params["exactMatch"] = "true"
                    if data.get("language"):
                        params["language"] = str(data["language"])
                    if data.get("documentLength"):
                        params["documentLength"] = str(data["documentLength"])
                    types = data.get("documentTypes") or []
                    if isinstance(types, list) and types:
                        params["documentTypes"] = ",".join(map(str, types[:30]))
                    upstream_path = "document/find-by/keyword/" + urllib.parse.quote(query, safe="") + "/"
                    result, _, upstream = self._loa_request(upstream_path, params, max_bytes=12 * 1024 * 1024)
                    hits = result.get("searchHits", []) if isinstance(result, dict) else []
                    self._json(200, {"ok": True, "searchHits": hits,
                                     "totalHitCount": result.get("totalHitCount", len(hits)) if isinstance(result, dict) else len(hits),
                                     "upstream": upstream, "status": self._loa_status(probe=False) | {"reachable": True, "ok": True}})
                else:
                    ids = data.get("sourceIds") or []
                    if not isinstance(ids, list):
                        raise ValueError("sourceIds must be an array")
                    rows = []
                    for source_id in ids[:8]:
                        sid = str(source_id)[:512]
                        try:
                            meta, _, _ = self._loa_request(f"document/{urllib.parse.quote(sid, safe='')}/debug", max_bytes=4 * 1024 * 1024)
                            rows.append({"sourceId": sid, "ok": True, "debug": meta})
                        except Exception as exc:
                            rows.append({"sourceId": sid, "ok": False, "error": str(exc)})
                    self._json(200, {"ok": True, "results": rows})
            except Exception as exc:
                self._json(502, {"ok": False, "error": str(exc), "status": self._loa_status(probe=False)})
            return
        if path not in {"/api/dev/session", "/api/dev/comment", "/api/dev/core-dump", "/api/dev/review-packet", "/api/dev/viewport-capture"}:
            self._json(404, {"ok": False, "error": "unknown endpoint"})
            return
        try:
            data = self._read_json()
            session_id = safe_name(str(data.get("sessionId") or "unknown-session"))
            folder = SESSIONS / session_id
            folder.mkdir(parents=True, exist_ok=True)

            if path == "/api/dev/session":
                atomic_json(folder / "session.json", data)
                dest = folder / "session.json"
            elif path == "/api/dev/comment":
                dest = folder / "comments.jsonl"
                with dest.open("a", encoding="utf-8") as fh:
                    fh.write(json.dumps(data, ensure_ascii=False) + "\n")
            elif path == "/api/dev/core-dump":
                dest = folder / f"core-{utcstamp()}.json"
                atomic_json(dest, data)
                atomic_json(folder / "core-latest.json", data)
            elif path == "/api/dev/viewport-capture":
                capture = data.get("capture") or {}
                data_url = str(capture.get("dataUrl") or "")
                prefix = "data:image/png;base64,"
                if not data_url.startswith(prefix):
                    raise ValueError("viewport capture is missing PNG data")
                raw = base64.b64decode(data_url[len(prefix):], validate=True)
                stamp = utcstamp()
                dest = folder / f"viewport-{stamp}.png"
                dest.write_bytes(raw)
                (folder / "viewport-latest.png").write_bytes(raw)
                meta = {k:v for k,v in capture.items() if k != "dataUrl"}
                meta.update({"release": data.get("release"), "sessionId": session_id, "saved": str(dest.relative_to(ROOT))})
                atomic_json(folder / f"viewport-{stamp}.json", meta)
                atomic_json(folder / "viewport-latest.json", meta)
            else:
                dest = folder / f"review-{utcstamp()}.json"
                atomic_json(dest, data)
                atomic_json(folder / "review-latest.json", data)

            self._json(200, {"ok": True, "saved": str(dest.relative_to(ROOT)), "sessionId": session_id})
            print(f"  ↳ saved {dest.relative_to(ROOT)}")
        except Exception as exc:
            self._json(400, {"ok": False, "error": str(exc)})


def main() -> int:
    ap = argparse.ArgumentParser(description="Launch RollamacoasterTycoon R3 and collect playtest diagnostics")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--no-open", action="store_true", help="do not open a browser automatically")
    ap.add_argument("--loa-base", default=os.getenv("RCT_LOA_BASE", ""), help="Library of Alexandria Web Application base URL, e.g. http://127.0.0.1:8081")
    ap.add_argument("--loa-timeout", type=float, default=DEFAULT_LOA_TIMEOUT)
    ap.add_argument("--loa-archive-max", type=int, default=DEFAULT_LOA_ARCHIVE_MAX, help="maximum bytes for one deliberately archived LoA document")
    args = ap.parse_args()

    artifact = ROOT / ARTIFACT
    if not artifact.exists():
        raise SystemExit(f"Missing {artifact}. Run: python3 build_rct_r3.py")
    SESSIONS.mkdir(exist_ok=True)

    server = ThreadingHTTPServer((args.host, args.port), Handler)
    server.loa_base = str(args.loa_base or "").rstrip("/")
    server.loa_timeout = max(1.0, float(args.loa_timeout))
    server.loa_archive_max = max(1024, int(args.loa_archive_max))
    url = f"http://{args.host}:{args.port}/{ARTIFACT}"
    print("\nROLLAMACOASTERTYCOON!! R3 DEVELOPMENT LOOP")
    print("=" * 52)
    print(f"Game:      {url}")
    print(f"Artifact:  {artifact}")
    print(f"Collector: {SESSIONS}")
    print(f"Alexandria: {server.loa_base or 'not configured (local cache/fallback only)'}")
    print("Loop:      RELEASE → TEST → COMMENTS → CORE DUMP → REVIEW → PLAN → BUILD → RELEASE")
    print("Stop:      Ctrl+C\n")

    if not args.no_open:
        threading.Timer(0.45, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nDevelopment server stopped.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
